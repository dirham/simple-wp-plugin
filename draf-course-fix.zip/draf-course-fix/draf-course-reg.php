<?php

function randkey($length){
	//    karakter yang bisa dipakai sebagai key
    $string = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
    $len = strlen($string);

	//    mengenerate key
    for($i=1;$i<=$length; $i++){
        $start = rand(0, $len);
        $key .= substr($string, $start, 1);
    }

    return $key;
}

function form_daftar_course() {
	echo '<form action="' . esc_url( $_SERVER['PHP_SELF'] ) . '" method="post">';
	echo '<p>';
	echo 'Instructor Name : (required) <br/>';
	echo '<input type="text" name="name-cd" value="' . ( isset( $_POST["name-cd"] ) ? esc_attr( $_POST["name-cd"] ) : '' ) . '" size="40" />';
	echo '</p>';
	echo '<p>';
	echo 'Participan Name : (required, ex : name1,name2,etc) <br/>';
	echo '<input type="text" name="nameList" value="' . ( isset( $_POST["nameList"] ) ? esc_attr( $_POST["nameList"] ) : '' ) . '" size="40" />';
	echo '</p>';
	echo '<p>';
	echo 'Email of student : (required, ex : student@mail.com, student1@mail.com) <br/>';
	echo '<input type="text" name="email" value="' . ( isset( $_POST["email"] ) ?  $_POST["email"] : '' ) . '" size="40" />';
	echo '</p>';
	echo '<p>';
	echo 'Select Level :';
	echo ' <select name="level">
				  <option value="DLS1">Dasar</option>
				  <option value="DLS2">Menengah</option>
				  <option value="DLS3">Mahir</option>
				  <option value="DLS4">Instructor</option>
				</select>';
	echo '</p>';
	echo '<p>';
	echo 'Subject (required) <br/>';
	echo '<input type="text" name="subject" pattern="[a-zA-Z ]+" value="' . ( isset( $_POST["subject"] ) ? esc_attr( $_POST["subject"] ) : '' ) . '" size="40" />';
	echo '</p>';
	echo '<p>';
	echo 'Enter your message (details for student) <br/>';
	echo '<textarea rows="10" cols="35" name="cf-message">' . ( isset( $_POST["cf-message"] ) ? esc_attr( $_POST["cf-message"] ) : '' ) . '</textarea>';
	echo '</p>';
	echo '<p><input type="submit" name="submitted" value="Send"></p>';
	echo '</form>';

}

function email_dan_simpan() {
		//membuat key ke student untuk kebutuhan registrasi student

		$key = randkey(11);

	// if the submit button is clicked, send the email
	if ( isset( $_POST['submitted'] ) ) {

		// sanitize form values
		$name    = sanitize_text_field( $_POST["name-cd"] );
		$studentnameList    = sanitize_text_field( $_POST["nameList"] );
		$email   =  $_POST["email"] ;
		$subject = sanitize_text_field( $_POST["subject"] );
		$message = esc_textarea( $_POST["cf-message"] );
		$keysend = "klick this link ".'<a href="http://localhost/dive/wp-admin/admin.php?page=draf_student_registered">this</a>'." and paste the key (bold) into the key form <b><h3>".$key." <-- this is the key </h3></b>";
		$text = $message.''.$keysend;
		// get the blog current user's email address
		$from = wp_get_current_user();
		$fromEmail = $from->user_email;
		// $to = get_option( 'admin_email' );
		$pengajar = $from->user_login;

		$headers = "From: $name <$fromEmail>" . "\r\n";

// echo $pengajar;
		add_filter( 'wp_mail_content_type', 'set_html_content_type' );
		global $wpdb;
		$insert = $wpdb->insert('wp_register_pelajar', array('id'=>'','list_student_name'=>$studentnameList,'email_pelajar'=>$email,'level'=>$_POST["level"],'email_pengajar'=>$fromEmail, 'key_user_register'=>$key, 'pengajar'=>$pengajar), array('%d', '%s', '%s','%s','%s', '%s','%s'));
		if($insert){
				echo '<div>';
				echo '<p>Data telah tersimpan</p>';
				echo '</div>';
				//jika berhasil menyimpan maka kirim email
				if ( wp_mail( $email, $subject, $text, $headers ) ) {
					echo '<div>';
					echo '<p>Thanks for contacting me, expect a response soon.</p>';
					echo '</div>';
					remove_filter( 'wp_mail_content_type', 'wpdocs_set_html_mail_content_type' );
					} else {
			           echo 'An unexpected error occurred';
			        }
		}else{
			if($wpdb->last_error !== '') :
			        $str   = htmlspecialchars( $wpdb->last_result, ENT_QUOTES );
			        $query = htmlspecialchars( $wpdb->last_query, ENT_QUOTES );
			        print "<div id='error'>
			        <p class='wpdberror'><strong>WordPress database error:</strong> [$str]<br />
			        <code>$query</code></p>
			        <p> $key</p>
			        </div>";
		    endif;
		echo "gaga;";
		}


	}
}

//untuk mengaktifkan html tag
function set_html_content_type()
{
    return 'text/html';
}
//test function
function call(){
form_daftar_course();
email_dan_simpan();
}

//akhir pembuatan form create course
?>
