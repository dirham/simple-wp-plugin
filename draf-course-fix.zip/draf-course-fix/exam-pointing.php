<?php

function form_examp_pointing() {
  //get student id untuk single user pointing
  $student_id = $_GET['id'];
  $multi_id   =$_GET['multiID'];
  global $wpdb;
  $exams = $wpdb->get_results("select exam_name from complyted_exam");
	echo '<form action="' . esc_url( $_SERVER['REQUEST_URI'] ) . '" method="post">';
  ?>
  <link type="text/css" href="<?php echo WP_PLUGIN_URL; ?>/draf-course/style-admin.css" rel="stylesheet" />
  <h3>Course result check</h3>
  <table class='wp-list-table widefat fixed striped posts'>
      <tr>
        <th class="bgth manage-column ss-list-width1">Participan Name</th>
  <?php
      $exam_total = 0;
      $exam_names=[];
      foreach ($exams as $exam) {
        $exam_total++;
        $exam_names[] = $exam;
  ?>
        <th class="bgth manage-column ss-list-width1"><?php echo $exam->exam_name; ?></th>
  <?php } ?>
  <th class="bgth manage-column ss-list-width" colspan="2">Action</th>
      </tr>
  <?php
  if ( empty( $student_id ) ){
    if ( isset($multi_id) ) {
      echo "<tr>";
      print_r($exam_names);
      $a = 0;
      $multi_student = $wpdb->get_results("select id, nama_pelajar from wp_registered_pelajar WHERE id IN ($multi_id)");
      foreach ($multi_student as $r ) {
        echo "<td class='manage-column ss-list-width'>$r->nama_pelajar <input type='hidden' value='$r->nama_pelajar' name='x-name[]'>
        <input type='hidden' value='$r->id' name='x-id'></td>";
        for ($i=0; $i<$exam_total; $i++){
          echo "<td class='manage-column ss-list-width'><input type='checkbox' name='exm".$i."[]' value='1'></td>";
          $a++;
        }
        echo "<td class='manage-column ss-list-width'><a href='#'>Delete Participan</a></td>";
        echo "</tr>";
      }
      // for ($i=0; $i<$exam_total; $i++){
      //   echo "<td class='manage-column ss-list-width'><input type='checkbox' name='exm$i'></td></tr>";
      // }
      // exit( var_dump( $wpdb->last_query ) );
      // print_r($multi_id);

    }else{
      echo "<tr>";
      echo "<td colspan='4' align='center'>Oooopss... There is no Student</td>";
      echo "</tr>";
    }

  }
  else{
    $one_student = $wpdb->get_results("select id, nama_pelajar from wp_registered_pelajar WHERE id = '$student_id'");
    foreach ($one_student as $r ) {
      echo "<td class='manage-column ss-list-width'>$r->nama_pelajar <input type='hidden' value='$r->nama_pelajar' name='x-name'>
      <input type='hidden' value='$r->id' name='x-id'></td>";
    }
    for ($i=0; $i<$exam_total; $i++){
      echo "<td class='manage-column ss-list-width'><input type='checkbox' name='exm$i'></td>";
    }
  }

  echo '</table><p><input type="submit" id="btn" name="p-submitted" value="Save Result"></p>';
	echo '</form>';

}

function save_courese_result() {
	// if the submit button is clicked, send the email
	if ( isset( $_POST['p-submitted'] ) ) {
    echo "post nama ";
    print_r($_POST['x-name']);
    echo "<br>";
    echo "post id ";
    print_r($_POST['x-id']);
    echo "<br>";
    echo "post checkbox 1 ";
    print_r($_POST['exm0']);
    echo "<br>";
    echo "post checkbox 2 ";

    print_r($_POST['exm1']);
    // global $wpdb;
    // $wpdb->query("INSERT INTO wp_exam_poin
    //         (`id`, `test_name`, `participan_name`, `status`)
    //         VALUES
    //         ($_POST['x-name'], 'val-1', current_time('mysql'), current_time('mysql'), 'user-1'),
    //         ('name-2', 'val-2', current_time('mysql'), current_time('mysql'), 'user-2'),
    //         ('name-3', 'val-3',  current_time('mysql'), current_time('mysql'), 'user-3')")

  }

}

function exam_call(){

form_examp_pointing();
save_courese_result();

}
